package rentcarsystemmanagement;
import java.sql.SQLException;
public class RentCarSystemManagement {

    public static void main(String[] args) throws SQLException{
    }
    
}
