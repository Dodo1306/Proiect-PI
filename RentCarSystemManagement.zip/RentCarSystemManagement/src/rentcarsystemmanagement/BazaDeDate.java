/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rentcarsystemmanagement;

/**
 *
 * @author enach
 */
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class BazaDeDate {
    public static void main(String[] args) {

        // creates Connection object
          Connection conn1 = null;
       

        try {
            // connect way #1
            String url1 = "jdbc:mysql://localhost:3307/rentcardb?zeroDateTimeBehavior=CONVERT_TO_NULL";
            String user = "root";
            String password = "";

            conn1 = DriverManager.getConnection(url1, user, password);
            if (conn1 != null) {
                System.out.println("Conexiunea a reusit");
                
                Statement stmt = conn1.createStatement();   
            }
            
        } catch (SQLException ex) {
            System.out.println("Ceva nu a mers bine! Verifica username-ul sau parola!");
            ex.printStackTrace();

        }
        finally {
            if (conn1 != null) {
                try {
                    conn1.close();
                }
                catch(Exception ex) {
                    ex.printStackTrace();
                }
            }
}
        
    }
  
}

